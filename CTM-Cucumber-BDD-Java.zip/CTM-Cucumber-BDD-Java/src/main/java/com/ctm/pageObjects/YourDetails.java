package com.ctm.pageObjects;

import com.ctm.factory.Pages;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class YourDetails extends Pages {

    @FindBy(css = ".variable-rate")
    private WebElement variableTariff;

    @FindBy(css = "label[for='pre-select-payment-quarterly']")
    private WebElement quarterlyDirectDebit;

    @FindBy(css = "#Email")
    private WebElement emailTextField;

    @FindBy(id = "terms-label")
    private WebElement termsAndCondition;

    @FindBy(css = ".button-primary")
    private WebElement goToPrices;


    public YourDetails selectVariableTariff() {
        try {
            waitForVisibilityOfElement(variableTariff).click();
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public YourDetails selectQuarterlyDirectDebit() {
        try {
            waitForVisibilityOfElement(quarterlyDirectDebit).click();
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public YourDetails enterEmail(String emailId) {
        try {
            waitForVisibilityOfElement(emailTextField).sendKeys(emailId);
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public YourDetails confirmTermsAndConditions() {
        try {
            waitForVisibilityOfElement(termsAndCondition).click();
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public YourResults selectGoToPrices() {
        try {
            waitForVisibilityOfElement(goToPrices).click();
            return new YourResults();
        } catch (NoSuchElementException ex) {
            return null;
        }
    }
}

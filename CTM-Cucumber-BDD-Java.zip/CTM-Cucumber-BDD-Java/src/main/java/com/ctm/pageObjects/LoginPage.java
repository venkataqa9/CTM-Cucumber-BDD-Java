package com.ctm.pageObjects;

import com.ctm.factory.Pages;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends Pages {
    @FindBy(css = ".main-heading.sign-in")
    private WebElement signInMessage;

    public boolean signInMessageIsDisplayed(String signInMessage) {
        try{
           return waitForVisibilityOfElement(this.signInMessage).getText().matches(signInMessage);
        } catch (NoSuchElementException ex){
            return false;
        }
    }
}

package com.ctm.pageObjects;

import com.ctm.factory.Pages;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EnergyPage extends Pages {

    @FindBy(id = "electricity-current-spend")
    private WebElement electricitySpend;

    @FindBy(id = "goto-your-energy")
    private WebElement energyNextButton;


    public EnergyPage enterAmountInUsage(String amount) {
        try {
            waitForVisibilityOfElement(electricitySpend).sendKeys(amount);
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public YourDetails energyNext() {
        try {
            waitForVisibilityOfElement(energyNextButton).click();
            return new YourDetails();
        } catch (NoSuchElementException ex) {
            return null;
        }
    }
}

package com.ctm.pageObjects;

import com.ctm.factory.Pages;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EnergyQuoteHomePage extends Pages {

    @FindBy(id = "sign-in-prompt-link")
    private WebElement previousEnergyQuoteButton;

    @FindBy(id = "your-postcode")
    private WebElement postCode;

    @FindBy(id = "find-postcode")
    private WebElement findPostcode;

    @FindBy(id = "no-bill-label")
    private WebElement noBill;

    @FindBy(id = "compare-electricity-label")
    private WebElement electricity;

    @FindBy(id = "goto-your-supplier-details")
    private WebElement nextButton;

    @FindBy(id = "confirm-tick-area")
    private WebElement dontKnow;


    public LoginPage selectPreviousEnergyQuotes() {
        try {
            waitForVisibilityOfElement(previousEnergyQuoteButton).click();
            return new LoginPage();
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public EnergyQuoteHomePage enterPostCode(String postCode) {
        try {
            waitForVisibilityOfElement(this.postCode).sendKeys(postCode);
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public EnergyQuoteHomePage findPostCode() {
        try {
            waitForVisibilityOfElement(findPostcode).click();
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public EnergyQuoteHomePage selectIHaveNoBill() {
        try {
            waitForVisibilityOfElement(noBill).click();
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public EnergyQuoteHomePage selectElectricity() {
        try {
            waitForVisibilityOfElement(electricity).click();
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public EnergyPage supplierNext() {
        try {
            Thread.sleep(2000);
            waitForVisibilityOfElement(nextButton).click();
            return new EnergyPage();
        } catch (NoSuchElementException | InterruptedException ex) {
            return null;
        }
    }


}

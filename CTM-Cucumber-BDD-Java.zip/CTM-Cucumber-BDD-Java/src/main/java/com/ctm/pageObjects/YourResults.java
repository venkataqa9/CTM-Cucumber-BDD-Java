package com.ctm.pageObjects;

import com.ctm.factory.Pages;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.NoSuchElementException;

public class YourResults extends Pages {

    @FindBy(css = "tbody[id^='tariffSelection']")
    private List<WebElement> tariffResults;

    @FindBy(id = "filters-payment-type-clear")
    private WebElement paymentsClearButton;

    @FindBy(id = "filters-payment-type-monthly")
    private WebElement monthlyPayment;

    @FindBy(css = "td.tariff-feature-payment-method")
    private WebElement paymentResult;


    public int tariffResultsAreMatched() {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 5);
            return wait.until(ExpectedConditions.visibilityOfAllElements(tariffResults)).size();
        } catch (NoSuchElementException ex) {
            return 0;
        }

    }

    public YourResults clearPaymentType() {
        try {
            waitForLoadToComplete();
            waitForVisibilityOfElement(paymentsClearButton).click();
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public YourResults selectMonthlyPaymentType() {
        try {
            waitForVisibilityOfElement(monthlyPayment).click();
            return this;
        } catch (NoSuchElementException ex) {
            return null;
        }
    }

    public boolean monthlyPaymentTypeResultsAreDisplayed(String paymentType) {
        try {
            return waitForVisibilityOfElement(paymentResult).getText().matches(paymentType);
        } catch (NoSuchElementException ex) {
            return false;
        }
    }
}

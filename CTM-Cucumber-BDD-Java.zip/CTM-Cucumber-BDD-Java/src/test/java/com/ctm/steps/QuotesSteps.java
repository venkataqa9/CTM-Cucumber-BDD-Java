package com.ctm.steps;

import com.ctm.pageObjects.*;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

import static org.hamcrest.MatcherAssert.assertThat;


public class QuotesSteps {

    LoginPage loginPage = new LoginPage();
    EnergyQuoteHomePage energyQuoteHomePage = new EnergyQuoteHomePage();
    EnergyPage energyPage = new EnergyPage();
    YourDetails yourDetails = new YourDetails();
    YourResults yourResults = new YourResults();

    @When("^I select previous energy quotes$")
    public void iSelectPreviousEnergyQuotes() {
        Assert.assertNotNull(energyQuoteHomePage.selectPreviousEnergyQuotes());
    }

    @Then("^I can see signin message \"([^\"]*)\" on login page$")
    public void iShouldSeeSigninMessageOnloginPage(String signInMessage) {
        Assert.assertTrue(loginPage.signInMessageIsDisplayed(signInMessage));
    }

    @Given("^I enter postcode \"([^\"]*)\"$")
    public void iEnterPostcode(String postCode) {
        Assert.assertNotNull(energyQuoteHomePage.enterPostCode(postCode)
                .findPostCode());
    }

    @When("^I select energy supplier$")
    public void iSelectEnergySupplier() {
        Assert.assertNotNull(energyQuoteHomePage.selectIHaveNoBill()
                .selectElectricity());
    }

    @And("^I select go to your supplier next$")
    public void iSelectGoToYourSupplierNext() {
        Assert.assertNotNull(energyQuoteHomePage.supplierNext());
    }


    @And("^I select go to your energy next$")
    public void iSelectGoToYourEnergyNext() {
        Assert.assertNotNull(energyPage.energyNext());
    }


    @And("^I enter amount usage \"([^\"]*)\" in your energy$")
    public void iEnterAmountUsageInYourEnergy(String amount) {
        Assert.assertNotNull(energyPage.enterAmountInUsage(amount));
    }

    @And("^I select variable tariff$")
    public void iSelectVariableTariff() {
        Assert.assertNotNull(yourDetails.selectVariableTariff());
    }

    @And("^I select quarterly direct debit$")
    public void iSelectQuarterlyDirectDebit() {
        Assert.assertNotNull(yourDetails.selectQuarterlyDirectDebit());
    }

    @And("^I enter email \"([^\"]*)\"$")
    public void iEnterEmail(String emailId) {
        Assert.assertNotNull(yourDetails.enterEmail(emailId));
    }

    @And("^I confirm terms and conditions$")
    public void iConfirmTermsAndConditions() {
        Assert.assertNotNull(yourDetails.confirmTermsAndConditions());
    }

    @And("^I select go to prices$")
    public void iSelectGoToPrices() {
        Assert.assertNotNull(yourDetails.selectGoToPrices());
    }

    @Then("^I can see atleast \"([^\"]*)\" tariff results$")
    public void iCanSeeAtleastTariffResults(int results) {
        Assert.assertEquals(yourResults.tariffResultsAreMatched(), results);

    }

    @And("^I clear payment type$")
    public void iClearPaymentType() {
        Assert.assertNotNull(yourResults.clearPaymentType());
    }

    @And("^I select monthly payment type$")
    public void iSelectMonthlyPaymentType() {
        Assert.assertNotNull(yourResults.selectMonthlyPaymentType());
    }

    @Then("^I can see results shown are monthly \"([^\"]*)\"payment type$")
    public void iCanSeeResultsShownAreMonthlyPaymentType(String paymentType) {
        Assert.assertTrue(yourResults.monthlyPaymentTypeResultsAreDisplayed(paymentType));
    }
}
